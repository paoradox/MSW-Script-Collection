# ============================================================================
# Windows Shared Printer Error Fix Script - Complete Edition
# Addresses ALL printer error codes for network/shared printer issues
# Run as Administrator for full functionality
# Created with love
# ============================================================================

param(
    [switch]$DryRun,
    [switch]$Verbose
)

$ErrorActionPreference = "Stop"

# ============================================================================
# Header Display
# ============================================================================
Write-Host "============================================" -ForegroundColor Cyan
Write-Host "  Windows Shared Printer Error Fix Script  " -ForegroundColor Cyan
Write-Host "  Make love not war. Happy Fixing :D                      " -ForegroundColor Magenta
Write-Host "============================================" -ForegroundColor Cyan
Write-Host ""

# ============================================================================
# Helper Functions
# ============================================================================
function Write-Log {
    param([string]$Message, [string]$Level = "INFO")
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $color = if($Level -eq "ERROR"){"Red"}elseif($Level -eq "SUCCESS"){"Green"}elseif($Level -eq "WARN"){"Yellow"}else{"Cyan"}
    Write-Host "[$timestamp] [$Level] $Message" -ForegroundColor $color
}

function Test-Admin {
    $currentUser = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($currentUser)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Set-RegistryValue {
    param([string]$Path, [string]$Name, $Value, [string]$Type = "DWord")
    
    if ($DryRun) {
        Write-Host "  [DRY RUN] Would set: $Path\$Name = $Value ($Type)" -ForegroundColor Gray
        return $true
    }
    
    try {
        if (-not (Test-Path $Path)) {
            New-Item -Path $Path -Force | Out-Null
        }
        New-ItemProperty -Path $Path -Name $Name -Value $Value -PropertyType $Type -Force | Out-Null
        Write-Host "  OK: Set $Path\$Name = $Value" -ForegroundColor Green
        return $true
    } catch {
        Write-Host "  FAIL: $Path\$Name - $_" -ForegroundColor Red
        return $false
    }
}

function Restart-Service-Safe {
    param([string]$ServiceName)
    
    if ($DryRun) {
        Write-Host "  [DRY RUN] Would restart service: $ServiceName" -ForegroundColor Gray
        return $true
    }
    
    try {
        $service = Get-Service -Name $ServiceName -ErrorAction SilentlyContinue
        if ($service) {
            Restart-Service -Name $ServiceName -Force
            Write-Host "  OK: Restarted service: $ServiceName" -ForegroundColor Green
            return $true
        } else {
            Write-Host "  WARN: Service not found: $ServiceName" -ForegroundColor Yellow
            return $false
        }
    } catch {
        Write-Host "  FAIL: Could not restart $ServiceName - $_" -ForegroundColor Red
        return $false
    }
}

function Stop-Service-Safe {
    param([string]$ServiceName)
    
    if ($DryRun) {
        Write-Host "  [DRY RUN] Would stop service: $ServiceName" -ForegroundColor Gray
        return $true
    }
    
    try {
        $service = Get-Service -Name $ServiceName -ErrorAction SilentlyContinue
        if ($service -and $service.Status -eq "Running") {
            Stop-Service -Name $ServiceName -Force
            Write-Host "  OK: Stopped service: $ServiceName" -ForegroundColor Green
            return $true
        }
        return $true
    } catch {
        Write-Host "  FAIL: Could not stop $ServiceName - $_" -ForegroundColor Red
        return $false
    }
}

function Start-Service-Safe {
    param([string]$ServiceName)
    
    if ($DryRun) {
        Write-Host "  [DRY RUN] Would start service: $ServiceName" -ForegroundColor Gray
        return $true
    }
    
    try {
        $service = Get-Service -Name $ServiceName -ErrorAction SilentlyContinue
        if ($service -and $service.Status -ne "Running") {
            Start-Service -Name $ServiceName
            Write-Host "  OK: Started service: $ServiceName" -ForegroundColor Green
            return $true
        }
        return $true
    } catch {
        Write-Host "  FAIL: Could not start $ServiceName - $_" -ForegroundColor Red
        return $false
    }
}

# ============================================================================
# Error Fix Functions
# ============================================================================

# Fix 0x00000709 - Default printer cannot be set
function Fix-Error0x00000709 {
    Write-Host "[01] Fix 0x00000709: Default printer cannot be set..." -ForegroundColor Green
    $path = "HKCU:\Software\Microsoft\Windows NT\CurrentVersion\Windows"
    Set-RegistryValue -Path $path -Name "Device" -Value "" -Type "String"
    Set-RegistryValue -Path $path -Name "LegacyDefaultPrinterMode" -Value 1
}

# Fix 0x0000011B - RPC security / PrintNightmare issue
function Fix-Error0x0000011B {
    Write-Host "[02] Fix 0x0000011B: RPC security / PrintNightmare issue..." -ForegroundColor Green
    $path = "HKLM:\System\CurrentControlSet\Control\Print"
    Set-RegistryValue -Path $path -Name "RpcAuthnLevelPrivacyEnabled" -Value 0
    Set-RegistryValue -Path $path -Name "RpcUseNamedPipeProtocol" -Value 1
}

# Fix 0x000006BA - RPC server unavailable
function Fix-Error0x000006BA {
    Write-Host "[03] Fix 0x000006BA: RPC server unavailable..." -ForegroundColor Green
    Set-RegistryValue -Path "HKLM:\System\CurrentControlSet\Services\RpcSs" -Name "Start" -Value 2
    Restart-Service-Safe "RpcSs"
}

# Fix 0x000006BE - RPC call failed
function Fix-Error0x000006BE {
    Write-Host "[04] Fix 0x000006BE: RPC call failed..." -ForegroundColor Green
    Set-RegistryValue -Path "HKLM:\System\CurrentControlSet\Services\Spooler" -Name "Start" -Value 2
    Restart-Service-Safe "Spooler"
}

# Fix 0x00000035 - Network path not found
function Fix-Error0x00000035 {
    Write-Host "[05] Fix 0x00000035: Network path not found..." -ForegroundColor Green
    Set-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanWorkstation" -Name "Start" -Value 2
    Set-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanWorkstation" -Name "DependOnService" -Value @("Bowser") -Type "MultiString"
}

# Fix 0x00000053 - Network path not found (printer share)
function Fix-Error0x00000053 {
    Write-Host "[06] Fix 0x00000053: Network path not found (printer share)..." -ForegroundColor Green
    Set-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer" -Name "Start" -Value 2
}

# Fix 0x00000040 - Network access denied
function Fix-Error0x00000040 {
    Write-Host "[07] Fix 0x00000040: Network access denied..." -ForegroundColor Green
    Set-RegistryValue -Path "HKLM:\System\CurrentControlSet\Services\LanmanWorkstation" -Name "AllowInsecureGuestAuth" -Value 1
}

# Fix 0x00000043 - Bad network name
function Fix-Error0x00000043 {
    Write-Host "[08] Fix 0x00000043: Bad network name..." -ForegroundColor Green
    Set-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer" -Name "AutoShareServer" -Value 1
    Set-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer" -Name "AutoShareWks" -Value 1
}

# Fix 0x00000057 - Invalid parameter
function Fix-Error0x00000057 {
    Write-Host "[09] Fix 0x00000057: Invalid parameter..." -ForegroundColor Green
    $path = "HKLM:\System\CurrentControlSet\Control\Print"
    Set-RegistryValue -Path $path -Name "EnableEventLog" -Value 1
    Set-RegistryValue -Path $path -Name "NetPrint" -Value 1
}

# Fix 0x0000007E - Driver module not found
function Fix-Error0x0000007E {
    Write-Host "[10] Fix 0x0000007E: Driver module not found..." -ForegroundColor Green
    if (-not $DryRun) {
        $driverCache = "$env:SystemRoot\System32\spool\drivers"
        if (Test-Path $driverCache) {
            Get-ChildItem $driverCache -Recurse -ErrorAction SilentlyContinue | Remove-Item -Force -Recurse -ErrorAction SilentlyContinue
            Write-Host "  OK: Cleared driver cache" -ForegroundColor Green
        }
    }
    # Ensure spool directories exist
    $spoolPath = "C:\Windows\System32\spool"
    if (Test-Path $spoolPath) {
        $dirs = @("DRIVERS", "PRINTERS", "SCRIPTS")
        foreach ($d in $dirs) {
            $fullPath = Join-Path $spoolPath $d
            if (-not (Test-Path $fullPath)) {
                New-Item -ItemType Directory -Path $fullPath -Force | Out-Null
            }
        }
    }
}

# Fix 0x0000007F - Driver procedure not found
function Fix-Error0x0000007F {
    Write-Host "[11] Fix 0x0000007F: Driver procedure not found..." -ForegroundColor Green
    Set-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Print\Drivers" -Name "Version" -Value 3
}
	
# Fix 0x00000012 - Print Cancelled Error
function Fix-Error0x00000012 {
      Write-Host "[12] Fix 0x00000012: Print cancelled error..." -ForegroundColor Green
      
      # Restart Print Spooler service
      Restart-Service -Name "Spooler" -Force
      
      # Clear print queue
     Stop-Service -Name "Spooler" -Force
     Remove-Item -Path "C:\Windows\System32\spool\PRINTERS\*" -Force
     Start-Service -Name "Spooler"
     Write-Host "[-] Print spooler restarted and queue cleared." -ForegroundColor Yellow
}

# Fix 0x80004005 - Enable Insecure Guest Access for Windows 11 LAN Sharing                                  
  function Fix-Error0x80004005 {                                                                              
    Write-Host "[09] Fix 0x80004005: Enable insecure guest logons..." -ForegroundColor Green                
      $path = "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanWorkstation\Parameters"                          
        Set-RegistryValue -Path $path -Name "AllowInsecureGuestAuth" -Value 1                                   
    Write-Host "[-] Insecure guest logons enabled. Restart required." -ForegroundColor Yellow
  }	

# Fix 0x0000011C - Printer driver blocked by policy
function Fix-Error0x0000011C {
    Write-Host "[12] Fix 0x0000011C: Printer driver blocked by policy..." -ForegroundColor Green
    $path = "HKLM:\Software\Policies\Microsoft\Windows NT\Printers"
    Set-RegistryValue -Path $path -Name "PointAndPrint" -Value 0
    Set-RegistryValue -Path $path -Name "PackagePointAndPrintServerList" -Value 0
}

# Fix 0x0000011D - Unknown printer driver
function Fix-Error0x0000011D {
    Write-Host "[13] Fix 0x0000011D: Unknown printer driver..." -ForegroundColor Green
    $path = "HKLM:\SYSTEM\CurrentControlSet\Control\Print\Environments"
    $envs = @("Windows NT x86", "Windows x64")
    foreach ($env in $envs) {
        $envPath = "$path\$env"
        if (Test-Path $envPath) {
            Write-Host "  OK: Verified driver environment: $env" -ForegroundColor Green
        }
    }
}

# Fix 0x0000011E - Invalid printer name
function Fix-Error0x0000011E {
    Write-Host "[14] Fix 0x0000011E: Invalid printer name..." -ForegroundColor Green
    $path = "HKCU:\Printers\Connections"
    if (Test-Path $path) {
        if (-not $DryRun) {
            Get-ChildItem $path -ErrorAction SilentlyContinue | Remove-Item -Force -ErrorAction SilentlyContinue
            Write-Host "  OK: Cleared invalid printer connections" -ForegroundColor Green
        }
    }
}

# Fix 0x0000011F - Printer already exists
function Fix-Error0x0000011F {
    Write-Host "[15] Fix 0x0000011F: Printer already exists..." -ForegroundColor Green
    $path = "HKCU:\Printers\Connections"
    if (-not $DryRun) {
        if (Test-Path $path) {
            Get-ChildItem $path -ErrorAction SilentlyContinue | ForEach-Object {
                Remove-Item -Path $_.PSPath -Force -ErrorAction SilentlyContinue
            }
            Write-Host "  OK: Cleared existing printer connections" -ForegroundColor Green
        }
    }
}

# Fix 0x00000120 - Printer not found
function Fix-Error0x00000120 {
    Write-Host "[16] Fix 0x00000120: Printer not found..." -ForegroundColor Green
    Set-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Print\Printers" -Name "Default" -Value "" -Type "String"
}

# Fix 0x00000706 - Invalid printer name (Devices)
function Fix-Error0x00000706 {
    Write-Host "[17] Fix 0x00000706: Invalid printer name (Devices)..." -ForegroundColor Green
    $path = "HKCU:\Software\Microsoft\Windows NT\CurrentVersion\Devices"
    if (-not $DryRun) {
        $props = Get-ItemProperty -Path $path -ErrorAction SilentlyContinue
        if ($props) {
            $props.PSObject.Properties | Where-Object { $_.Name -like "*,*" } |
                ForEach-Object { Remove-ItemProperty -Path $path -Name $_.Name -Force -ErrorAction SilentlyContinue }
        }
        Write-Host "  OK: Cleaned invalid device entries" -ForegroundColor Green
    }
}

# Fix 0x0000071A - Spooler not responding over network
function Fix-Error0x0000071A {
    Write-Host "[18] Fix 0x0000071A: Spooler not responding over network..." -ForegroundColor Green
    Set-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Spooler" -Name "Start" -Value 2
    Set-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Spooler" -Name "DependOnService" -Value @("RPCSS") -Type "MultiString"
    Restart-Service-Safe "Spooler"
}

# Fix 0x0000071B - Printer driver download failed
function Fix-Error0x0000071B {
    Write-Host "[19] Fix 0x0000071B: Printer driver download failed..." -ForegroundColor Green
    $path = "HKLM:\Software\Policies\Microsoft\Windows NT\Printers\PointAndPrint"
    if (-not (Test-Path $path)) { New-Item -Path $path -Force | Out-Null }
    Set-RegistryValue -Path $path -Name "NoWarningNoElevationOnInstall" -Value 1
    Set-RegistryValue -Path $path -Name "UpdatePromptSettings" -Value 0
}

# Fix 0x0000071C - Driver package rejected
function Fix-Error0x0000071C {
    Write-Host "[20] Fix 0x0000071C: Driver package rejected..." -ForegroundColor Green
    $path = "HKLM:\Software\Policies\Microsoft\Windows NT\Printers\PackagePointAndPrint"
    if (-not (Test-Path $path)) { New-Item -Path $path -Force | Out-Null }
    Set-RegistryValue -Path $path -Name "PackagePointAndPrintOnly" -Value 0
}

# Fix 0x00000721 - Driver mismatch on print server
function Fix-Error0x00000721 {
    Write-Host "[21] Fix 0x00000721: Driver mismatch on print server..." -ForegroundColor Green
    if (-not $DryRun) {
        $cachePath = "$env:SystemRoot\System32\spool\drivers"
        if (Test-Path $cachePath) {
            Get-ChildItem $cachePath -ErrorAction SilentlyContinue | Remove-Item -Force -ErrorAction SilentlyContinue
            Write-Host "  OK: Cleared driver mismatch cache" -ForegroundColor Green
        }
    }
}

# Fix 0x00000722 - Printer authentication failure
function Fix-Error0x00000722 {
    Write-Host "[22] Fix 0x00000722: Printer authentication failure..." -ForegroundColor Green
    $path = "HKLM:\Software\Policies\Microsoft\Windows NT\Printers"
    Set-RegistryValue -Path $path -Name "RpcUseNamedPipeProtocol" -Value 1
    Set-RegistryValue -Path $path -Name "AuthenticatePrinters" -Value 0
}

# Fix 0x00000723 - Printer permission denied
function Fix-Error0x00000723 {
    Write-Host "[23] Fix 0x00000723: Printer permission denied..." -ForegroundColor Green
    Set-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Print\Printers" -Name "Security" -Value 1
}

# Fix 0x00000724 - Printer share unreachable
function Fix-Error0x00000724 {
    Write-Host "[24] Fix 0x00000724: Printer share unreachable..." -ForegroundColor Green
    Set-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanWorkstation" -Name "Start" -Value 2
    Set-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanWorkstation" -Name "AllowInsecureGuestAuth" -Value 1
}

# Fix 0x00000726 - Network printer timeout
function Fix-Error0x00000726 {
    Write-Host "[25] Fix 0x00000726: Network printer timeout..." -ForegroundColor Green
    $path = "HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters"
    Set-RegistryValue -Path $path -Name "TcpMaxConnectRetransmissions" -Value 5
    Set-RegistryValue -Path $path -Name "TcpMaxDataRetransmissions" -Value 5
}

# Fix 0x0000003A - Network busy
function Fix-Error0x0000003A {
    Write-Host "[26] Fix 0x0000003A: Network busy..." -ForegroundColor Green
    Set-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanWorkstation" -Name "MaxCmds" -Value 50
    Set-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer" -Name "MaxCmds" -Value 50
}

# Fix 0x00000041 - Network resource unavailable
function Fix-Error0x00000041 {
    Write-Host "[27] Fix 0x00000041: Network resource unavailable..." -ForegroundColor Green
    Set-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanWorkstation" -Name "KeepConn" -Value 600
    Set-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanWorkstation" -Name "SessTimeout" -Value 3600
}

# Fix 0x00000047 - Network busy or congested
function Fix-Error0x00000047 {
    Write-Host "[28] Fix 0x00000047: Network busy or congested..." -ForegroundColor Green
    Set-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanWorkstation" -Name "MaxThreads" -Value 255
    Set-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer" -Name "MaxWorkItems" -Value 8192
}

# Fix 0x0000004C - Too many connections to printer share
function Fix-Error0x0000004C {
    Write-Host "[29] Fix 0x0000004C: Too many connections to printer share..." -ForegroundColor Green
    Set-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer" -Name "Users" -Value 999
    Set-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer" -Name "MaxRawWorkItems" -Value 100
}

# Fix 0x0000004D - Print server connection limit reached
function Fix-Error0x0000004D {
    Write-Host "[30] Fix 0x0000004D: Print server connection limit reached..." -ForegroundColor Green
    Set-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer" -Name "MaxMpxCount" -Value 1000
    Set-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer" -Name "MaxRawWorkItems" -Value 200
}

# Fix 0x00000051 - Remote computer not available
function Fix-Error0x00000051 {
    Write-Host "[31] Fix 0x00000051: Remote computer not available..." -ForegroundColor Green
    Set-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanWorkstation" -Name "SessTimeout" -Value 3600
    Set-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanWorkstation" -Name "KeepConn" -Value 600
}

# Fix 0x00000054 - Network busy during print job
function Fix-Error0x00000054 {
    Write-Host "[32] Fix 0x00000054: Network busy during print job..." -ForegroundColor Green
    Set-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Print" -Name "RpcRetryTimes" -Value 5
    Set-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Print" -Name "RpcSleepInterval" -Value 100
}

# Fix 0x00000055 - Network BIOS command limit reached
function Fix-Error0x00000055 {
    Write-Host "[33] Fix 0x00000055: Network BIOS command limit reached..." -ForegroundColor Green
    Set-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Services\NetBT\Parameters" -Name "MaxCmds" -Value 50
    Set-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Services\NetBT\Parameters" -Name "MaxDatagrams" -Value 100
}

# Fix 0x00000056 - Network BIOS session limit reached
function Fix-Error0x00000056 {
    Write-Host "[34] Fix 0x00000056: Network BIOS session limit reached..." -ForegroundColor Green
    Set-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Services\NetBT\Parameters" -Name "MaxSessions" -Value 255
    Set-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Services\NetBT\Parameters" -Name "MaxSessionsPerName" -Value 64
}

# Fix 0x0000005B - Network request not supported
function Fix-Error0x0000005B {
    Write-Host "[35] Fix 0x0000005B: Network request not supported..." -ForegroundColor Green
    Set-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanWorkstation" -Name "EnableSecuritySignature" -Value 0
    Set-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanWorkstation" -Name "RequireSecuritySignature" -Value 0
}

# Fix 0x0000005C - Remote adapter not compatible
function Fix-Error0x0000005C {
    Write-Host "[36] Fix 0x0000005C: Remote adapter not compatible..." -ForegroundColor Green
    Set-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanWorkstation" -Name "DisableBandwidthDetection" -Value 1
}

# Fix 0x0000005D - Print server queue unavailable
function Fix-Error0x0000005D {
    Write-Host "[37] Fix 0x0000005D: Print server queue unavailable..." -ForegroundColor Green
    Set-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Print" -Name "EnableRemoteUX" -Value 1
    Set-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Spooler" -Name "Start" -Value 2
    Restart-Service-Safe "Spooler"
}

# Fix 0x0000005E - Print server busy
function Fix-Error0x0000005E {
    Write-Host "[38] Fix 0x0000005E: Print server busy..." -ForegroundColor Green
    Set-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Print" -Name "ThreadPriority" -Value 1
    Set-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Spooler" -Name "Priority" -Value 8
}

# Fix 0x00000063 - Printer share name conflict
function Fix-Error0x00000063 {
    Write-Host "[39] Fix 0x00000063: Printer share name conflict..." -ForegroundColor Green
    $path = "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Shares"
    if (-not $DryRun) {
        $props = Get-ItemProperty -Path $path -ErrorAction SilentlyContinue
        if ($props) {
            $props.PSObject.Properties | Where-Object { $_.Name -notmatch "^$" -and $_.Name -notmatch "Flags|Type|MaxUsers|CurrentUsers|PSPath|PSParentPath|PSChildName|PSDrive|PSProvider" } |
                ForEach-Object { Write-Host "  Found share: $($_.Name)" -ForegroundColor Gray }
        }
    }
}

# Fix 0x00000064 - Network printer name deleted
function Fix-Error0x00000064 {
    Write-Host "[40] Fix 0x00000064: Network printer name deleted..." -ForegroundColor Green
    $path = "HKCU:\Printers\Connections"
    if (-not $DryRun) {
        if (Test-Path $path) {
            Remove-Item -Path $path -Recurse -Force -ErrorAction SilentlyContinue
        }
        New-Item -Path $path -Force | Out-Null
        Write-Host "  OK: Reset printer connections" -ForegroundColor Green
    }
}

# Fix 0x00000065 - Network access temporarily denied
function Fix-Error0x00000065 {
    Write-Host "[41] Fix 0x00000065: Network access temporarily denied..." -ForegroundColor Green
    Set-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer" -Name "AutoDisconnect" -Value 15
    Set-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanWorkstation" -Name "RestoreTimeout" -Value 60
}

# Fix 0x00000067 - Network name cannot be found
function Fix-Error0x00000067 {
    Write-Host "[42] Fix 0x00000067: Network name cannot be found..." -ForegroundColor Green
    Set-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Services\NetBT\Parameters" -Name "NodeType" -Value 2
    Set-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Services\NetBT\Parameters" -Name "EnableLMHOSTS" -Value 1
}

# Fix 0x0000006A - Print queue paused
function Fix-Error0x0000006A {
    Write-Host "[43] Fix 0x0000006A: Print queue paused..." -ForegroundColor Green
    Set-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Print\Printers" -Name "Pause" -Value 0
    if (-not $DryRun) {
        Get-Printer -ErrorAction SilentlyContinue | Where-Object { $_.WorkOffline -eq $true } | ForEach-Object {
            try {
                Resume-Printer -Name $_.Name -ErrorAction SilentlyContinue
            } catch {
                # Resume-Printer not available, skip
            }
        }
    }
    Write-Host "  OK: Printer queues resumed" -ForegroundColor Green
}

# Fix 0x00000079 - Semaphore timeout (network printer)
function Fix-Error0x00000079 {
    Write-Host "[44] Fix 0x00000079: Semaphore timeout (network printer)..." -ForegroundColor Green
    Set-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanWorkstation" -Name "SessTimeout" -Value 3600
    Set-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanWorkstation" -Name "SendTimeout" -Value 30000
}

# Fix 0x0000007B - Invalid network printer path
function Fix-Error0x0000007B {
    Write-Host "[45] Fix 0x0000007B: Invalid network printer path..." -ForegroundColor Green
    $path = "HKCU:\Printers\Connections"
    if (-not $DryRun) {
        if (Test-Path $path) {
            Get-ChildItem $path -ErrorAction SilentlyContinue | 
                Where-Object { $_.Name -notmatch "\\\\" } |
                Remove-Item -Force -ErrorAction SilentlyContinue
            Write-Host "  OK: Removed invalid printer paths" -ForegroundColor Green
        }
    }
}

# Fix 0x0000007C - Printer driver not found on server
function Fix-Error0x0000007C {
    Write-Host "[46] Fix 0x0000007C: Printer driver not found on server..." -ForegroundColor Green
    $path = "HKLM:\Software\Policies\Microsoft\Windows NT\Printers\PointAndPrint"
    if (-not (Test-Path $path)) { New-Item -Path $path -Force | Out-Null }
    Set-RegistryValue -Path $path -Name "TrustedServers" -Value 1
    Set-RegistryValue -Path $path -Name "ServerList" -Value "" -Type "String"
}

# Fix 0x000000BB - Print provider not available
function Fix-Error0x000000BB {
    Write-Host "[47] Fix 0x000000BB: Print provider not available..." -ForegroundColor Green
    Restart-Service-Safe "Spooler"
    Set-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Print\Providers" -Name "Load" -Value 1
}

# Fix 0x000006BF - RPC call failed and did not execute
function Fix-Error0x000006BF {
    Write-Host "[48] Fix 0x000006BF: RPC call failed and did not execute..." -ForegroundColor Green
    Set-RegistryValue -Path "HKLM:\System\CurrentControlSet\Services\RpcSs" -Name "Start" -Value 2
    Set-RegistryValue -Path "HKLM:\System\CurrentControlSet\Services\Spooler" -Name "Start" -Value 2
    Restart-Service-Safe "RpcSs"
    Restart-Service-Safe "Spooler"
}

# Fix 0x0000071D - Printer connection policy restriction
function Fix-Error0x0000071D {
    Write-Host "[49] Fix 0x0000071D: Printer connection policy restriction..." -ForegroundColor Green
    $path = "HKLM:\Software\Policies\Microsoft\Windows NT\Printers"
    Set-RegistryValue -Path $path -Name "AllowPrintServerRB" -Value 1
    Set-RegistryValue -Path $path -Name "DisableHTTPPrinting" -Value 0
}

# Fix 0x00000725 - Print queue offline on server
function Fix-Error0x00000725 {
    Write-Host "[50] Fix 0x00000725: Print queue offline on server..." -ForegroundColor Green
    Set-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Print" -Name "RetryInterval" -Value 5
    Set-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Print" -Name "RetryCount" -Value 10
    if (-not $DryRun) {
        Get-Printer -ErrorAction SilentlyContinue | Where-Object { $_.WorkOffline -eq $true } | ForEach-Object {
            try { Resume-Printer -Name $_.Name -ErrorAction SilentlyContinue } catch {}
        }
    }
    Write-Host "  OK: Printer queues resumed" -ForegroundColor Green
}

# Fix HP Error 710 - Printhead/Cartridge Issue
     function Fix-Error710 {
     Write-Host "[710] Fix HP Error 710: Printhead/Cartridge issue..." -ForegroundColor Green
    
      # Restart Print Spooler
      Restart-Service -Name "Spooler" -Force
      
      # Reset printer configuration
      $path = "HKLM:\SYSTEM\CurrentControlSet\Control\Print"
     Set-ItemProperty -Path $path -Name "RestartOnFailure" -Value 1 -Type DWORD -Force
     
     Write-Host "[-] Print spooler restarted. Clean printhead manually." -ForegroundColor Green
     Write-Host "[!] Manual steps required:" -ForegroundColor Green
     Write-Host "    1. Open printer cover"
     Write-Host "    2. Remove and reseat printhead/cartridges"
     Write-Host "    3. Clean electrical contacts with lint-free cloth"
     Write-Host "    4. Run printer's built-in cleaning utility"
     
}

# Fix 0x00000727 - Printer server certificate issue
function Fix-Error0x00000727 {
    Write-Host "[51] Fix 0x00000727: Printer server certificate issue..." -ForegroundColor Green
    $path = "HKLM:\Software\Policies\Microsoft\Windows NT\Printers"
    Set-RegistryValue -Path $path -Name "RpcUseTLS" -Value 0
    Set-RegistryValue -Path $path -Name "ClientRenderGDI" -Value 1
}

# Additional fixes from makentosh script
function Fix-CredentialManager {
    Write-Host "[52] Clearing stale credentials..." -ForegroundColor Green
    if (-not $DryRun) {
        cmd.exe /c "cmdkey /list" 2>$null | Select-String "Target:" | ForEach-Object {
            $target = ($_ -replace ".*Target: ", "").Trim()
            if ($target -like "*print*" -or $target -like "*spool*" -or $target -like "*termsrv*") {
                cmd.exe /c "cmdkey /delete:$target" 2>$null | Out-Null
            }
        }
        Write-Host "  OK: Stale credentials cleared" -ForegroundColor Green
    }
}

function Fix-FirewallRules {
    Write-Host "[53] Configuring firewall rules..." -ForegroundColor Green
    if (-not $DryRun) {
        netsh advfirewall firewall add rule name="RPC-EPMAP" dir=in action=allow protocol=TCP localport=135 2>$null | Out-Null
        netsh advfirewall firewall add rule name="RPC-Dynamic" dir=in action=allow protocol=TCP localport=49152-65535 2>$null | Out-Null
        netsh advfirewall firewall add rule name="Printer-9100" dir=in action=allow protocol=TCP localport=9100 2>$null | Out-Null
        netsh advfirewall firewall add rule name="Printer-515" dir=in action=allow protocol=TCP localport=515 2>$null | Out-Null
        Write-Host "  OK: Firewall rules configured" -ForegroundColor Green
    }
}

function Fix-ServiceDependencies {
    Write-Host "[54] Verifying service dependencies..." -ForegroundColor Green
    try {
        $spooler = Get-Service -Name "Spooler" -ErrorAction Stop
        $deps = $spooler.ServicesDependedOn
        foreach ($dep in $deps) {
            if ($dep.Status -ne "Running") {
                Start-Service -Name $dep.Name -ErrorAction SilentlyContinue
            }
        }
        Write-Host "  OK: Service dependencies verified" -ForegroundColor Green
    } catch {
        Write-Host "  FAIL: $_" -ForegroundColor Red
    }
}

function Fix-PrintQueue {
    Write-Host "[55] Clearing print queue..." -ForegroundColor Green
    if (-not $DryRun) {
        Stop-Service-Safe "Spooler"
        Remove-Item -Path "C:\Windows\System32\spool\PRINTERS\*" -Force -ErrorAction SilentlyContinue
        Start-Service-Safe "Spooler"
        Write-Host "  OK: Print queue cleared" -ForegroundColor Green
    }
}

function Fix-LSASecurity {
    Write-Host "[56] Configuring LSA security settings..." -ForegroundColor Green
    Set-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -Name "LimitBlankPasswordUse" -Value 1
    Set-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -Name "NoLmHash" -Value 1
}

function Fix-NetworkSharing {
    Write-Host "[57] Enabling network sharing..." -ForegroundColor Green
    if (-not $DryRun) {
        Set-NetFirewallProfile -Profile Private,Public -Enabled True -ErrorAction SilentlyContinue
        netsh advfirewall firewall set rule group="File and Printer Sharing" new enable=Yes 2>$null | Out-Null
        Write-Host "  OK: Network sharing enabled" -ForegroundColor Green
    }
}

function Fix-PrinterQueues {
    Write-Host "[58] Resuming printer queues..." -ForegroundColor Green
    if (-not $DryRun) {
        Get-Printer -ErrorAction SilentlyContinue | ForEach-Object {
            $p = $_
            if ($p.PrinterStatus -eq "Paused") {
                try { Resume-Printer -Name $p.Name -ErrorAction SilentlyContinue } catch {}
            }
        }
        Write-Host "  OK: Printer queues resumed" -ForegroundColor Green
    }
}

function Fix-NetworkStack {
    Write-Host "[59] Resetting network stack..." -ForegroundColor Green
    if (-not $DryRun) {
        netsh int ip reset 2>$null | Out-Null
        netsh winsock reset 2>$null | Out-Null
        Write-Host "  OK: Network stack reset commands queued (restart required)" -ForegroundColor Green
    }
}

function Fix-SpoolerPriority {
    Write-Host "[60] Configuring spooler priority..." -ForegroundColor Green
    Set-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Print" -Name "SpoolerPriority" -Value 1
}

function Fix-ComputerName {
    Write-Host "[61] Validating computer name..." -ForegroundColor Green
    $hostname = $env:COMPUTERNAME
    Write-Host "  Computer Name: $hostname" -ForegroundColor Gray
    if ($hostname -match "[^a-zA-Z0-9-]") {
        Write-Host "  WARN: Computer name contains invalid characters!" -ForegroundColor Yellow
    } else {
        Write-Host "  OK: Computer name is valid" -ForegroundColor Green
    }
}

# Fix 0x0000004B - Network printer not responding
function Fix-Error0x0000004B {
    Write-Host "[64] Fix 0x0000004B: Network printer not responding..." -ForegroundColor Green

    $path = "HKLM:\SYSTEM\CurrentControlSet\Control\Print\Printers"

    if (-not $DryRun) {
        Get-Printer -ErrorAction SilentlyContinue | ForEach-Object {
            try {
                Set-Printer -Name $_.Name -WorkOffline $false -ErrorAction SilentlyContinue
            } catch {}
        }
    }

    Set-RegistryValue -Path $path -Name "RetryInterval" -Value 5
    Set-RegistryValue -Path $path -Name "RetryCount" -Value 10
}

# Fix 0x000000AA - Printer port already exists
function Fix-Error0x000000AA {
    Write-Host "[65] Fix 0x000000AA: Printer port already exists..." -ForegroundColor Green

    $portPath = "HKLM:\SYSTEM\CurrentControlSet\Control\Print\Monitors\Standard TCP/IP Port\Ports"

    if (-not $DryRun) {

        $ports = Get-ChildItem $portPath -ErrorAction SilentlyContinue

        foreach ($p in $ports) {

            $ip = $p.PSChildName.Replace("IP_","")

            if ($ip -match "^\d+\.\d+\.\d+\.\d+$") {

                if (!(Test-Connection $ip -Count 1 -Quiet)) {

                    Remove-Item $p.PSPath -Recurse -Force -ErrorAction SilentlyContinue
                    Write-Host "  Removed stale port: $($p.PSChildName)" -ForegroundColor Yellow
                }

            }

        }

    }
}

# Fix 0x0000072A - Printer TCP port misconfigured
function Fix-Error0x0000072A {
    Write-Host "[66] Fix 0x0000072A: TCP/IP printer port misconfigured..." -ForegroundColor Green

    $path = "HKLM:\SYSTEM\CurrentControlSet\Control\Print\Monitors\Standard TCP/IP Port"

    Set-RegistryValue -Path $path -Name "ProtocolSupported" -Value 1
    Set-RegistryValue -Path $path -Name "EnableSNMP" -Value 0
}

# Improve TCP settings for static IP printers
function Fix-TCPPrinterOptimization {
    Write-Host "[67] Optimizing TCP/IP for static printer connections..." -ForegroundColor Green

    $path = "HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters"

    Set-RegistryValue -Path $path -Name "TcpMaxDataRetransmissions" -Value 5
    Set-RegistryValue -Path $path -Name "TcpMaxConnectRetransmissions" -Value 5
    Set-RegistryValue -Path $path -Name "KeepAliveTime" -Value 300000
}


function Fix-Win32Spl {
    Write-Host "[62] Configuring Win32 Spl provider..." -ForegroundColor Green
    $win32SplPath = "HKLM:\SYSTEM\CurrentControlSet\Control\Print\Providers\Win32 Spl"
    if (-not (Test-Path $win32SplPath)) {
        New-Item -Path $win32SplPath -Force | Out-Null
    }
    Set-RegistryValue -Path $win32SplPath -Name "AllowPrintServerRB" -Value 1
}

function Fix-FullSystemRecon {
    Write-Host "[63] Running full system repair..." -ForegroundColor Magenta
    if (-not $DryRun) {
        netsh winsock reset catalog 2>$null | Out-Null
        netsh int ip reset reset.log 2>$null | Out-Null
        $dlls = @("ole32.dll", "oleaut32.dll", "mshtml.dll", "shdocvw.dll")
        foreach ($dll in $dlls) {
            regsvr32.exe /s $dll 2>$null | Out-Null
        }
        Write-Host "  Running SFC scan..." -ForegroundColor Gray
        Start-Process -FilePath "sfc.exe" -ArgumentList "/scannow" -WindowStyle Hidden 2>$null
        Write-Host "  OK: System repair commands executed" -ForegroundColor Green
    }
}

# ============================================================================
# Main Execution
# ============================================================================
function Main {
    # Check admin rights
    $isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    
    if (-not $isAdmin) {
        Write-Host ""
        Write-Host "WARNING: This script should be run as Administrator!" -ForegroundColor Yellow
        Write-Host "Right-click PowerShell and select 'Run as Administrator'" -ForegroundColor Yellow
        
        if (-not $DryRun) {
            $continue = Read-Host "Continue anyway? (y/n)"
            if ($continue -ne 'y') { exit }
        }
        Write-Host ""
    }
    
    if ($DryRun) {
        Write-Host "Running in DRY RUN mode - no changes will be made" -ForegroundColor Yellow
        Write-Host ""
    }
    
    Write-Host "Starting printer error fixes..." -ForegroundColor Cyan
    Write-Host ""
    
    # Execute all fixes
    Fix-Error0x00000709
    Fix-Error0x0000011B
    Fix-Error0x000006BA
    Fix-Error0x000006BE
    Fix-Error0x00000035
    Fix-Error0x00000053
    Fix-Error0x00000040
    Fix-Error0x00000043
    Fix-Error0x00000057
    Fix-Error0x0000007E
    Fix-Error0x0000007F
    Fix-Error0x0000011C
    Fix-Error0x0000011D
    Fix-Error0x0000011E
    Fix-Error0x0000011F
    Fix-Error0x00000120
    Fix-Error0x00000706
    Fix-Error0x0000071A
    Fix-Error0x0000071B
    Fix-Error0x0000071C
    Fix-Error0x00000721
    Fix-Error0x00000722
    Fix-Error0x00000723
    Fix-Error0x00000724
    Fix-Error0x00000726
    Fix-Error0x0000003A
    Fix-Error0x00000041
    Fix-Error0x00000047
    Fix-Error0x0000004C
    Fix-Error0x0000004D
    Fix-Error0x00000051
    Fix-Error0x00000054
    Fix-Error0x00000055
    Fix-Error0x00000056
    Fix-Error0x0000005B
    Fix-Error0x0000005C
    Fix-Error0x0000005D
    Fix-Error0x0000005E
    Fix-Error0x00000063
    Fix-Error0x00000064
    Fix-Error0x00000065
    Fix-Error0x00000067
    Fix-Error0x0000006A
    Fix-Error0x00000079
    Fix-Error0x0000007B
    Fix-Error0x0000007C
    Fix-Error0x000000BB
    Fix-Error0x000006BF
    Fix-Error0x0000071D
    Fix-Error0x00000725
    Fix-Error0x00000727
	Fix-Error0x80004005
	Fix-Error0x00000012
    Fix-CredentialManager
	Fix-Error710
    Fix-FirewallRules
    Fix-ServiceDependencies
    Fix-PrintQueue
    Fix-LSASecurity
    Fix-NetworkSharing
    Fix-PrinterQueues
    Fix-NetworkStack
    Fix-SpoolerPriority
    Fix-ComputerName
    Fix-Win32Spl
    Fix-FullSystemRecon
    Fix-Error0x0000004B
    Fix-Error0x000000AA
    Fix-Error0x0000072A
    Fix-TCPPrinterOptimization
    
    Write-Host ""
    Write-Host "Restarting Print Spooler service..." -ForegroundColor Yellow
    Restart-Service-Safe "Spooler"

    Write-Host ""
    Write-Host "============================================" -ForegroundColor Cyan
    Write-Host "  Fix Complete - Next Steps                " -ForegroundColor Cyan
    Write-Host "  Created with love - Makentosh                        " -ForegroundColor Magenta
    Write-Host "============================================" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "1. RESTART your computer to apply all changes" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "2. On HOST (printer attached):" -ForegroundColor White
    Write-Host "   - Enable printer sharing in Control Panel" -ForegroundColor Gray
    Write-Host "   - Share the printer" -ForegroundColor Gray
    Write-Host ""
    Write-Host "3. On CLIENT:" -ForegroundColor White
    Write-Host "   - Add printer: \\<HOST-NAME>\<Printer-Share-Name>" -ForegroundColor Gray
    Write-Host ""
    Write-Host "4. If issues persist:" -ForegroundColor White
    Write-Host "   - Ensure both PCs use Private network profile" -ForegroundColor Gray
    Write-Host "   - Enable Network Discovery and File Sharing" -ForegroundColor Gray
    Write-Host "   - Update Windows on both machines" -ForegroundColor Gray
    Write-Host ""
    
    if (-not $DryRun) {
        Write-Host "Press any key to exit..." -ForegroundColor Gray
        $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    }
}

Main
