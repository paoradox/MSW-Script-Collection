@echo off
:: ============================================================================
:: Windows Shared Printer Error Fix Script - Batch Launcher
:: Launches the PowerShell script with proper permissions
:: Created with love
:: ============================================================================

echo ============================================
echo   Printer Error Fix - Launcher
echo   Created with love
echo ============================================
echo.

:: Check if running as administrator
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo [WARNING] Not running as Administrator!
    echo.
    echo Please right-click this file and select:
    echo   "Run as administrator"
    echo.
    echo Attempting to restart with admin privileges...
    echo.
    
    :: Try to elevate
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

echo [OK] Running as Administrator
echo.

:: Get the directory where this batch file is located
set "SCRIPT_DIR=%~dp0"

:: Check if PS1 file exists
if not exist "%SCRIPT_DIR%PrinterErrorFix.ps1" (
    echo [ERROR] PrinterErrorFix.ps1 not found!
    echo Expected location: %SCRIPT_DIR%PrinterErrorFix.ps1
    echo.
    pause
    exit /b 1
)

echo [OK] Found PrinterErrorFix.ps1
echo.
echo Starting fixes...
echo.

:: Run PowerShell script with execution policy bypass
powershell -ExecutionPolicy Bypass -File "%SCRIPT_DIR%PrinterErrorFix.ps1"

echo.
echo ============================================
echo   Done!
echo ============================================
echo.
pause
