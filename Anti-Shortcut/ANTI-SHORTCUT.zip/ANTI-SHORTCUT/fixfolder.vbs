' Reset the file attributes of All the Folder in a specific Drive
' Change Z: to the drive letter where you want the change will happen.

cDrive = "H:"

Set FSO = CreateObject("Scripting.FileSystemObject")
ShowSubfolders FSO.GetFolder(cDrive)
WScript.Echo "Done with fix."

Sub ShowSubFolders(Folder)
    str = ""
    For Each Subfolder in Folder.SubFolders
        str = str & " " & Subfolder.Path
        subFolder.Attributes = 0
        ShowSubFolders Subfolder
    Next
End Sub